const mongoose = require('mongoose');
const MONGO_URI = process.env.MONGO_URI;

// Define Todo Schema
const todoSchema = new mongoose.Schema({
  task: String,
  completed: Boolean
});

const Todo = mongoose.models.Todo || mongoose.model('Todo', todoSchema);

let conn = null;

exports.handler = async (event) => {
  if (conn == null) {
    conn = await mongoose.connect(MONGO_URI);
  }

  const corsHeaders = {
    "Content-Type": "application/json",
    "Access-Control-Allow-Origin": "https://todolistappfrontend.vercel.app",
    "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS"
  };

  try {
    const { httpMethod, pathParameters, body } = event;

    if (httpMethod === 'OPTIONS') {
      return {
        statusCode: 200,
        headers: corsHeaders,
        body: JSON.stringify({}),
      };
    }

    switch (httpMethod) {
      case 'GET':
        const todos = await Todo.find();
        return {
          statusCode: 200,
          headers: corsHeaders,
          body: JSON.stringify(todos),
        };

      case 'POST':
        const postData = JSON.parse(body);
        const newTodo = await Todo.create({ task: postData.task, completed: false });
        return {
          statusCode: 201,
          headers: corsHeaders,
          body: JSON.stringify(newTodo),
        };

      case 'PUT':
        if (!pathParameters || !pathParameters.id) {
          return {
            statusCode: 400,
            headers: corsHeaders,
            body: JSON.stringify({ error: "ID is required for update" }),
          };
        }
        const putData = JSON.parse(body);
        const updatedTodo = await Todo.findByIdAndUpdate(pathParameters.id, putData, { new: true });
        return {
          statusCode: 200,
          headers: corsHeaders,
          body: JSON.stringify(updatedTodo),
        };

      case 'DELETE':
        if (!pathParameters || !pathParameters.id) {
          return {
            statusCode: 400,
            headers: corsHeaders,
            body: JSON.stringify({ error: "ID is required for delete" }),
          };
        }
        await Todo.findByIdAndDelete(pathParameters.id);
        return {
          statusCode: 200,
          headers: corsHeaders,
          body: JSON.stringify({}),
        };

      default:
        return {
          statusCode: 405,
          headers: corsHeaders,
          body: JSON.stringify({ error: `Method ${httpMethod} Not Allowed` }),
        };
    }

  } catch (err) {
    return {
      statusCode: 500,
      headers: corsHeaders,
      body: JSON.stringify({ error: err.message }),
    };
  }
};
